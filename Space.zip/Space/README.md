# PSFree version 1.5.0

Lapse Kex ported to 9.00 - Still WIP

Very fast and reliable but can KP :P

- Needs a bin loader on Port 9020.
- Some performance Tweaks??.
- Add sysveri Patch
  
PR are welcome 

PSFree is a collection of exploits for the PS4 console. The main focus of the 
repo is for the PS4 but we try to make things portable to PS5.

* Exploits
  * PSFree: src/psfree.mjs
  * Lapse (kernel): src/scripts/lapse.mjs

Donation (Monero/XMR):
86Fk3X9AE94EGKidzRbvyiVgGNYD3qZnuKNq1ZbsomFWXHYm6TtAgz9GNGitPWadkS3Wr9uXoT29U1SfdMtJ7QNKQpW1CVS

# COPYRIGHT AND AUTHORS:
AGPL-3.0-or-later (see src/COPYING). This repo belongs to the group
`anonymous`. We refer to anonymous contributors as "anonymous" as well.

# CREDITS:
* anonymous for PS4 firmware kernel dumps
* Check the appropriate files for any **extra** contributors. Unless otherwise
  stated, everything here can also be credited to us.
